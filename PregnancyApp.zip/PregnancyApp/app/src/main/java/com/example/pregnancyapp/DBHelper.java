package com.example.pregnancyapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    //Table name
    public static final String PROFILE_TABLE = "PROFILE";


    //Table Columns for STUDENT
    public static final String PROFILE_ID = "_id";
    public static final String EMAIL = "Email";
    public static final String PASSWORD = "Password";


    public static final String FIRST_NAME = "FirstName";
    public static final String LAST_NAME = "LastName";
    public static final String AGE = "Age";

    public static final String BABY_NAME = "BabyName";
    public static final String BABY_SEX = "BabySex";
    public static final String FIRST_CHILD = "FirstChild";





    //Database Information
    public static final String DB_NAME = "Pregnancy.DB";
    public static final int DB_VERSION = 1;

    //CREATE table query for PROFILE
    public static final String CREATE_PROFILE_TABLE = "CREATE TABLE " + PROFILE_TABLE + "(" + PROFILE_ID +
            " INTEGER PRIMARY KEY AUTOINCREMENT, " +EMAIL + " TEXT NOT NULL, "+ PASSWORD +
            " TEXT NOT NULL, " + FIRST_NAME + " TEXT NOT NULL, "
            + LAST_NAME + " TEXT NOT NULL, " + AGE + " TEXT NOT NULL, " + BABY_NAME + " TEXT NOT NULL, " +
            BABY_SEX + " TEXT NOT NULL, " +FIRST_CHILD + " TEXT NOT NULL );";



    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDb) {
        sqLiteDb.execSQL(CREATE_PROFILE_TABLE);


        // MOCK QUERIES - DELETE THIS CODE
        sqLiteDb.execSQL(MockData.ADD_MOCK_PROFILES);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDB, int oldVersion, int newVersion) {
        sqLiteDB.execSQL("DROP TABLE IF EXISTS " + PROFILE_TABLE);
        onCreate(sqLiteDB);
    }
}
