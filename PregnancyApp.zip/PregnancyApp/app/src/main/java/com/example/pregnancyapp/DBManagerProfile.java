package com.example.pregnancyapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DBManagerProfile {
    private DBHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public DBManagerProfile(Context c){
        context = c;
    }

    public DBManagerProfile open() throws SQLException {
        dbHelper = new DBHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(String email, String password, String firstName, String lastName, String age, String babyName, String babySex, String firstChild){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBHelper.EMAIL, firstName);
        contentValues.put(DBHelper.PASSWORD, lastName);
        contentValues.put(DBHelper.FIRST_NAME, email);
        contentValues.put(DBHelper.LAST_NAME, password);
        contentValues.put(DBHelper.AGE, age);
        contentValues.put(DBHelper.BABY_NAME, babyName);
        contentValues.put(DBHelper.BABY_SEX, babySex);
        contentValues.put(DBHelper.FIRST_CHILD, firstChild);


        database.insert(DBHelper.PROFILE_TABLE, null, contentValues);
    }

    public Cursor fetch() {
        String[] columns = new String[] { DBHelper.PROFILE_ID, DBHelper.EMAIL, DBHelper.PASSWORD, DBHelper.FIRST_NAME, DBHelper.LAST_NAME, DBHelper.AGE, DBHelper.BABY_NAME, DBHelper.BABY_SEX, DBHelper.FIRST_CHILD };
        Cursor cursor = database.query(DBHelper.PROFILE_TABLE, columns, null, null, null, null, null);

        return cursor;
    }

    public int update(long id, String email, String password, String firstName, String lastName, String age, String babyName, String babySex, String firstChild){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBHelper.EMAIL, firstName);
        contentValues.put(DBHelper.PASSWORD, lastName);
        contentValues.put(DBHelper.FIRST_NAME, email);
        contentValues.put(DBHelper.LAST_NAME, password);
        contentValues.put(DBHelper.AGE, age);
        contentValues.put(DBHelper.BABY_NAME, babyName);
        contentValues.put(DBHelper.BABY_SEX, babySex);
        contentValues.put(DBHelper.FIRST_CHILD, firstChild);

        int updateData = database.update(DBHelper.PROFILE_TABLE, contentValues, DBHelper.PROFILE_ID + " = " + id, null);
        return updateData;
    }

    public void delete(long id) {
        database.delete(DBHelper.PROFILE_TABLE, DBHelper.PROFILE_ID + "=" + id, null);
    }
}
