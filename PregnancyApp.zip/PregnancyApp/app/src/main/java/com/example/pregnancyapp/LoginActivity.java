package com.example.pregnancyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private DBManagerProfile dbManagerProfile;
    private TextView tvRegister;
    private Button btnLogin;
    EditText etEmail;
    EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        dbManagerProfile = new DBManagerProfile(this);
        dbManagerProfile.open();

        tvRegister = findViewById(R.id.btnRegister);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegisterActivity();
            }
        });
        btnLogin = findViewById(R.id.btnLoginLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyLogin();
                //openNavigationActivity();

            }
        });
    }

    private void verifyLogin() {
        etEmail = findViewById(R.id.etRegisterEmail);
        etPassword = findViewById(R.id.etRegisterPassword);

        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();

        Cursor c = dbManagerProfile.fetch();


        if (c != null) {
            c.moveToFirst();
            while(!c.isLast()) {
                if(c.getString(1).equals(email)){
                    break;
                }
                c.moveToNext();
            }
            if(c.getString(1).equals(email)){
                if(c.getString(2).equals(password)){
                    openNavigationActivity();
                } else {
                    Toast.makeText(this, "Your password is incorrect.", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Your email is incorrect.", Toast.LENGTH_LONG).show();
            }
        }
    }


    private void openNavigationActivity() {
        Intent intent = new Intent(this, NavigationActivity.class);
        startActivity(intent);
    }
    private void openRegisterActivity() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}
