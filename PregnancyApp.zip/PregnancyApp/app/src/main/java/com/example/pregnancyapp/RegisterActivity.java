package com.example.pregnancyapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, DatePickerDialog.OnDateSetListener {

    private DBManagerProfile dbManagerProfile;

    Spinner spinnerAge;
    Spinner spinnerSex;
    TextView pickDueDate;
    Button btnRegister;
    EditText etFirstName;
    EditText etLastName;
    EditText etEmail;
    EditText etPassword;
    Switch swFirstBaby;
    EditText etBabyName;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initializing DBManager
        dbManagerProfile = new DBManagerProfile(this);
        dbManagerProfile.open();

        spinnerAge = findViewById(R.id.spnAge);
        ArrayAdapter<CharSequence> adapterAge = ArrayAdapter.createFromResource(this, R.array.ages, android.R.layout.simple_spinner_item);
        adapterAge.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAge.setAdapter(adapterAge);
        spinnerAge.setOnItemSelectedListener(this);


        spinnerSex = findViewById(R.id.spnSexBaby);
        ArrayAdapter<CharSequence> adapterSex = ArrayAdapter.createFromResource(this, R.array.sex, android.R.layout.simple_spinner_item);
        adapterSex.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSex.setAdapter(adapterSex);
        spinnerSex.setOnItemSelectedListener(this);

        pickDueDate = findViewById(R.id.tvPickDate);
        pickDueDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });

        btnRegister = findViewById(R.id.btnRegister2);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addProfileData();
            }
        });


    }

    private void addProfileData() {
        etFirstName = findViewById(R.id.etRegisterFName);
        etLastName = findViewById(R.id.etRegisterFLame);
        etEmail = findViewById(R.id.etRegisterEmail);
        etPassword = findViewById(R.id.etRegisterPassword);
        swFirstBaby = findViewById(R.id.switch1);
        etBabyName = findViewById(R.id.adtBabyName);
        spinnerAge = findViewById(R.id.spnAge);
        spinnerSex = findViewById(R.id.spnSexBaby);

        String firstName = etFirstName.getText().toString();
        String lastName = etLastName.getText().toString();
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        String babyName = etBabyName.getText().toString();
        String babySex = spinnerSex.getSelectedItem().toString();
        String age = spinnerAge.getSelectedItem().toString();
        String firstBaby = "";

        if(swFirstBaby.isChecked()){
            firstBaby = "yes";
        }
        else{
            firstBaby = "no";
        }

        if(firstName.equals("") || lastName.equals("") || email.equals("") || password.equals("") || babyName.equals("") || firstBaby.equals("") || babySex.equals("") || age.equals("")){
            Toast.makeText(this, "Please, fill all fields.", Toast.LENGTH_LONG).show();
        } else {
            dbManagerProfile.insert(email, password, firstName, lastName, age, babySex, firstBaby, babyName);
            openLoginActivity();
        }
    }

    private void openLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

        String currentDataString = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        pickDueDate.setText(currentDataString);
    }
}
