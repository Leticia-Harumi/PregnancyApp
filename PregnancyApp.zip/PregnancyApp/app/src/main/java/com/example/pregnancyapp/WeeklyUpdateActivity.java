package com.example.pregnancyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WeeklyUpdateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekly_update);
    }
}