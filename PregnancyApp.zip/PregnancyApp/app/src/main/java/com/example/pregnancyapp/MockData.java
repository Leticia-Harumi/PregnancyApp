package com.example.pregnancyapp;

public class MockData {

    public static final String ADD_MOCK_PROFILES = "insert into PROFILE ( ProfileId, Email, Password, FirstName, LastName, Age, BabyName, BabyGender, FirstChild) values " +
            "(1, 'gskirving0@admin.ch', 'mA9_T3*$&', 'Darb', 'Skirving', '12', 'Goldarina', 'Female', ‘yes’)," +
            "(2, 'zhurling1@noaa.gov', 'bQ2''h30', 'Gregory', 'Hurling', '41', 'Zonda', 'Non-binary', ‘no’)," +
            "(3, 'hpalfrey2@flavors.me', 'oI4{}', 'Layla', 'Palfrey', '58', 'Heida', 'Female', ‘yes’)," +
            "(4, 'rroder3@storify.com', 'vN3`HW/', 'Rosanna', 'Roder', '23', 'Reggi', 'Female', ‘no’)," +
            "(5, 'blebel4@vinaora.com', 'gS2}k6H', 'Rene', 'Lebel', '29', 'Benedict', 'Male', ‘yes’);";
}
